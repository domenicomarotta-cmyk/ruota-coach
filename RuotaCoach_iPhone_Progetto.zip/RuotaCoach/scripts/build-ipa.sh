#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v xcodebuild >/dev/null; then
  echo 'Serve macOS con Xcode completo installato e selezionato.' >&2
  exit 1
fi
xcodebuild -project RuotaCoach.xcodeproj -scheme RuotaCoach -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build CODE_SIGNING_ALLOWED=NO build
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
mkdir -p "$stage/Payload" dist
cp -R build/Build/Products/Release-iphoneos/RuotaCoach.app "$stage/Payload/"
(cd "$stage" && /usr/bin/zip -qr RuotaCoach.ipa Payload)
mv "$stage/RuotaCoach.ipa" dist/RuotaCoach.ipa
echo 'Creato dist/RuotaCoach.ipa — da firmare e installare con AltStore Classic.'
