# Collaudo da eseguire su Xcode e iPhone

Non eseguito in questa consegna: manca l’ambiente Apple.

1. Compilare Debug e Release; provare su simulatore e iPhone 13.
2. Creare due clienti, cercarli, rinominarli e modificare le note.
3. Creare un’indagine con 0, 3, 4, 5, 6, 10: verificare spicchi e colori rosso/rosso/giallo/giallo/verde/verde.
4. Verificare che un’area non valutata impedisca il salvataggio e che 0 sia valido.
5. Salvare date e note, terminare l’app e riaprirla: controllare tutti i dati.
6. Modificare un’indagine esistente: non deve comparire un duplicato.
7. Cambiare palette e soglie: solo le nuove indagini devono usarle.
8. Esportare JSON, creare un cliente temporaneo, ripristinare: il cliente temporaneo deve sparire solo dopo conferma.
9. Importare JSON errato, versione diversa, voti fuori intervallo e ID duplicati: rifiuto senza modifica dell’archivio.
10. Annullare importazione, cancellazione e modifiche: nessuna modifica inattesa.
11. Cancellare una singola indagine, poi un cliente: gli altri dati devono restare.
12. Verificare tastiera, testo grande, VoiceOver, tema chiaro/scuro e leggibilità sullo schermo iPhone 13.
13. Installare l’IPA con AltStore Classic; verificare apertura, persistenza e aggiornamento con stesso identificatore.
