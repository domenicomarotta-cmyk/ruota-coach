# Ruota Coach — Domenico Marotta

Prima versione sorgente di un’app nativa SwiftUI per iPhone, iOS 16 o successivo. Progettata per iPhone 13, con schermate scorrevoli e supporto al tema di sistema.

## Stato della consegna

Il pacchetto contiene i sorgenti, un progetto Xcode, lo script per generare l’IPA e un workflow GitHub Actions. NON contiene un IPA già compilato. Nell’ambiente di creazione non erano disponibili macOS, Xcode o il simulatore iOS: compilazione, firma e test su dispositivo restano da eseguire. I controlli locali sono strutturali, non una certificazione di funzionamento dell’app.

## Funzioni implementate

- Gestione clienti: creazione, modifica nome e note, ricerca, cancellazione confermata.
- Storico per cliente: nuove indagini, modifica, cancellazione confermata, ordinamento per data.
- Data e ora dell’indagine, obiettivo, note del coach.
- Ruota con sei spicchi e dieci anelli: Possibilità esterna, Possibilità interna, Efficacia e risorse, Ecologia, Volontà, Merito.
- Voti interi 0–10 con pulsanti − e +. Il primo tocco assegna 0. “—” significa non ancora valutato; tutte le aree devono avere un voto per salvare.
- Gli spicchi si colorano fino all’anello del voto. I numeri 1–6 collegano la ruota alla legenda dei controlli.
- Sei colori preimpostati modificabili dalle impostazioni.
- Semaforo di default: rosso 0–3, giallo 4–5, verde 6–10. Soglie modificabili.
- Colori e soglie vengono conservati in ogni indagine per mantenere coerente lo storico.
- Archivio JSON locale con scrittura atomica e protezione file iOS. L’app non usa servizi di rete né account.
- Esportazione JSON e ripristino con convalida e conferma prima della sostituzione. Prima del ripristino si conserva anche una copia interna dell’archivio precedente.
- VoiceOver per la ruota e i controlli principali; colori del semaforo accompagnati da testo nelle schede di valutazione.

Le modifiche sono registrate premendo **Salva**. Annulla le scarta. Non è previsto salvataggio automatico delle bozze.
Il semaforo è uno strumento di lavoro configurabile, non una valutazione clinica o una scala validata.

## Ottenere l’IPA su Mac

1. Installa Xcode completo, aprilo almeno una volta e installa il supporto iOS richiesto.
2. Apri `RuotaCoach.xcodeproj` e prova l’app sul simulatore iPhone. Seleziona lo schema RuotaCoach.
3. Dal Terminale, entra nella cartella del progetto ed esegui:

```bash
bash scripts/build-ipa.sh
```

4. Il file generato è `dist/RuotaCoach.ipa`. È un pacchetto senza firma, destinato alla firma da parte di AltStore Classic.

Per l’installazione diretta da Xcode, imposta il tuo team in Signing & Capabilities. Lo script per AltStore disattiva invece la firma durante la compilazione. Non servono credenziali Apple nello script.

## Se usi Windows: compilazione remota opzionale

Puoi usare un runner macOS di GitHub Actions. Il workflow è incluso, ma NON è stato eseguito né pubblicato per te.

1. Crea un repository GitHub, preferibilmente privato, e carica **il contenuto** della cartella RuotaCoach nella radice. Includi la cartella nascosta `.github`.
2. Apri Actions, abilita i workflow se richiesto e avvia “Compila IPA per AltStore” con Run workflow.
3. Se la compilazione termina correttamente, scarica l’artefatto RuotaCoach-IPA e decomprimi lo ZIP per ottenere `RuotaCoach.ipa`.
4. Non caricare mai backup dei clienti nel repository. I runner macOS possono consumare minuti a pagamento secondo il tuo piano GitHub: verifica il piano prima dell’avvio.

## Installazione con AltStore

Il percorso previsto è **AltStore Classic**, con cui firmare/installare il file IPA personale. Per installazione, requisiti e rinnovo della firma segui la documentazione ufficiale aggiornata:

- https://faq.altstore.io/altstore-classic
- https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows
- https://faq.altstore.io/altstore-classic/altserver

Dopo aver configurato Classic, usa la funzione per aggiungere un IPA e seleziona RuotaCoach.ipa. Le firme personali hanno vincoli e richiedono rinnovi secondo l’account e la versione di AltStore. Conserva lo stesso identificatore app per gli aggiornamenti; esporta sempre un backup prima di reinstallare. Non disinstallare l’app per rinnovarla.

## Dati

Archivio in Application Support/RuotaCoach/archivio.json, nella sandbox privata dell’app. I backup esportati sono JSON in chiaro: se scegli iCloud Drive come destinazione saranno salvati lì per tua scelta. Anche i normali backup del dispositivo dipendono dalle impostazioni iOS. La disinstallazione può eliminare l’archivio locale.

Se il caricamento dell’archivio fallisce, le modifiche vengono bloccate per evitare di sovrascrivere i dati: è possibile ripristinare un backup valido. Nessun dato reale è incluso nel progetto.

## Verifica prima dell’uso con clienti

Vedi COLLAUDO.md. Prima prova con nominativi e note fittizi, chiudi e riapri l’app e verifica l’esportazione/ripristino.
