import Foundation
import Combine

let areaNames = ["Possibilità esterna", "Possibilità interna", "Efficacia e risorse", "Ecologia", "Volontà", "Merito"]
struct Settings: Codable, Equatable {
    var colors = ["2878BD", "7754BA", "15968D", "6B932B", "D17A24", "BC4E7D"]
    var redMax = 3
    var greenMin = 6
    func level(_ score: Int) -> String {
        score < 0 ? "Da valutare" : score <= redMax ? "Rosso" : score < greenMin ? "Giallo" : "Verde"
    }
}
struct Survey: Codable, Identifiable, Equatable {
    var id = UUID()
    var date = Date()
    var objective = ""
    var scores = Array(repeating: -1, count: 6)
    var notes = ""
    var settings = Settings()
    var complete: Bool { scores.count == 6 && scores.allSatisfy { (0...10).contains($0) } }
}
struct Client: Codable, Identifiable, Equatable {
    var id = UUID()
    var name = ""
    var notes = ""
    var surveys: [Survey] = []
}
struct Archive: Codable, Equatable {
    var version = 1
    var settings = Settings()
    var clients: [Client] = []
    func validate() throws {
        func valid(_ s: Settings) -> Bool {
            s.colors.count == 6 && s.colors.allSatisfy { $0.count == 6 && UInt32($0, radix: 16) != nil } &&
            (0...8).contains(s.redMax) && (s.redMax + 1...10).contains(s.greenMin)
        }
        guard version == 1, valid(settings), Set(clients.map(\.id)).count == clients.count else { throw DataError.invalid }
        var ids = Set<UUID>()
        for client in clients {
            guard !client.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw DataError.invalid }
            for survey in client.surveys {
                guard survey.complete, valid(survey.settings), ids.insert(survey.id).inserted else { throw DataError.invalid }
            }
        }
    }
}
enum DataError: LocalizedError {
    case invalid
    var errorDescription: String? { "Archivio non valido o versione non supportata. Nessun dato è stato sostituito." }
}
@MainActor final class Store: ObservableObject {
    @Published private(set) var archive = Archive()
    @Published var error: String?
    @Published private(set) var loadFailed = false
    private let url: URL
    init() {
        url = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("RuotaCoach/archivio.json")
        do {
            if FileManager.default.fileExists(atPath: url.path) {
                let loaded = try JSONDecoder().decode(Archive.self, from: Data(contentsOf: url))
                try loaded.validate()
                archive = loaded
            }
        } catch { loadFailed = true; self.error = "Impossibile aprire l’archivio. I dati originali sono conservati. \(error.localizedDescription)" }
    }
    @discardableResult func commit(_ next: Archive, recovery: Bool = false) -> Bool {
        guard !loadFailed || recovery else { error = "Ripristina un backup valido prima di modificare i dati."; return false }
        do {
            try next.validate()
            try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            let data = try encoder.encode(next)
            if recovery && FileManager.default.fileExists(atPath: url.path) {
                let preserved = url.deletingLastPathComponent().appendingPathComponent("prima-ripristino-\(UUID().uuidString).json")
                try FileManager.default.copyItem(at: url, to: preserved)
            }
            try data.write(to: url, options: [.atomic, .completeFileProtection])
            archive = next; loadFailed = false
            return true
        } catch { self.error = "Salvataggio non riuscito: \(error.localizedDescription)"; return false }
    }
    func save(_ client: Client) -> Bool {
        var next = archive
        if let i = next.clients.firstIndex(where: { $0.id == client.id }) { next.clients[i] = client }
        else { next.clients.append(client) }
        return commit(next)
    }
    func save(_ survey: Survey, for id: UUID) -> Bool {
        guard var client = archive.clients.first(where: { $0.id == id }) else { return false }
        if let i = client.surveys.firstIndex(where: { $0.id == survey.id }) { client.surveys[i] = survey }
        else { client.surveys.append(survey) }
        return save(client)
    }
}
