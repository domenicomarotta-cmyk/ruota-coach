import SwiftUI
import UniformTypeIdentifiers
import UIKit

extension Color {
    init(hex: String) {
        let n = UInt32(hex, radix: 16) ?? 0
        self.init(.sRGB, red: Double((n >> 16) & 255)/255, green: Double((n >> 8) & 255)/255, blue: Double(n & 255)/255, opacity: 1)
    }
    var hex: String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        UIColor(self).getRed(&r, green: &g, blue: &b, alpha: &a)
        return String(format: "%02X%02X%02X", Int(r*255), Int(g*255), Int(b*255))
    }
}
@main struct RuotaCoachApp: App {
    @StateObject private var store = Store()
    var body: some Scene {
        WindowGroup {
            HomeView().environmentObject(store).tint(Color(hex: "226B88"))
                .alert("Archivio", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
                    Button("OK") { store.error = nil }
                } message: { Text(store.error ?? "") }
        }
    }
}
struct HomeView: View {
    @EnvironmentObject var store: Store
    @State private var query = ""
    @State private var add = false
    @State private var settings = false
    var filtered: [Client] {
        store.archive.clients.filter { query.isEmpty || $0.name.localizedCaseInsensitiveContains(query) }
            .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }
    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("RUOTA DEL COACH").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                        Text("Ogni percorso,\nuna nuova prospettiva.").font(.title2.bold())
                        Text("6 aree · Valutazioni da 0 a 10 · Archivio locale").font(.caption)
                    }.padding(.vertical, 10)
                }
                Section("Coachee / clienti · \(store.archive.clients.count)") {
                    if filtered.isEmpty { Text(query.isEmpty ? "Aggiungi il primo cliente per iniziare." : "Nessun risultato.").foregroundStyle(.secondary) }
                    ForEach(filtered) { client in
                        NavigationLink(value: client.id) {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(client.name).font(.headline)
                                Text("\(client.surveys.count) indagini").font(.caption).foregroundStyle(.secondary)
                                if let latest = client.surveys.max(by: { $0.date < $1.date }) {
                                    Text("Ultima: \(latest.date.formatted(date: .abbreviated, time: .omitted))").font(.caption).foregroundStyle(.secondary)
                                }
                            }.padding(.vertical, 4)
                        }
                    }
                }
            }
            .navigationTitle("Il tuo studio")
            .searchable(text: $query, prompt: "Cerca un cliente")
            .navigationDestination(for: UUID.self) { ClientView(id: $0) }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button { settings = true } label: { Image(systemName: "gearshape") }.accessibilityLabel("Impostazioni e backup") }
                ToolbarItem(placement: .navigationBarTrailing) { Button { add = true } label: { Image(systemName: "person.badge.plus") }.disabled(store.loadFailed).accessibilityLabel("Aggiungi cliente") }
            }
            .sheet(isPresented: $add) { ClientEditor(client: Client()) }
            .sheet(isPresented: $settings) { SettingsView() }
        }
    }
}
struct ClientEditor: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    @State var client: Client
    var body: some View {
        NavigationStack {
            Form {
                Section("Anagrafica") { TextField("Nome e cognome", text: $client.name).textContentType(.name) }
                Section("Note sul percorso") { TextEditor(text: $client.notes).frame(minHeight: 160) }
            }.navigationTitle("Scheda cliente")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) { Button("Salva") {
                        client.name = client.name.trimmingCharacters(in: .whitespacesAndNewlines)
                        if store.save(client) { dismiss() }
                    }.disabled(client.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
                }
        }.interactiveDismissDisabled()
    }
}
struct ClientView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    let id: UUID
    @State private var editing: Client?
    @State private var survey: Survey?
    @State private var deleteClient = false
    @State private var deletingSurvey: Survey?
    var client: Client? { store.archive.clients.first { $0.id == id } }
    var body: some View {
        Group {
            if let client = client {
                List {
                    if !client.notes.isEmpty { Section("Note sul percorso") { Text(client.notes) } }
                    Section {
                        Button { survey = Survey(settings: store.archive.settings) } label: { Label("Nuova indagine", systemImage: "plus.circle.fill") }
                    }
                    Section("Storico indagini") {
                        if client.surveys.isEmpty { Text("Le indagini salvate compariranno qui.").foregroundStyle(.secondary) }
                        ForEach(client.surveys.sorted { $0.date > $1.date }) { item in
                            Button { survey = item } label: {
                                VStack(alignment: .leading, spacing: 8) {
                                    Text(item.date.formatted(date: .abbreviated, time: .shortened)).font(.headline).foregroundStyle(.primary)
                                    if !item.objective.isEmpty { Text(item.objective).foregroundStyle(.primary) }
                                    HStack(spacing: 12) { ForEach(0..<6) { i in Signal(score: item.scores[i], settings: item.settings, compact: true) } }
                                    let low = item.scores.filter { $0 < item.settings.greenMin }.count
                                    Text(low == 0 ? "Tutte le aree in verde" : "\(low) aree sotto soglia").font(.caption).foregroundStyle(.secondary)
                                }.padding(.vertical, 6)
                            }.swipeActions { Button(role: .destructive) { deletingSurvey = item } label: { Label("Elimina", systemImage: "trash") } }
                        }
                    }
                    Section { Button("Elimina cliente e storico", role: .destructive) { deleteClient = true } }
                }.navigationTitle(client.name)
                    .toolbar { Button("Modifica") { editing = client } }
            } else { Text("Cliente non disponibile") }
        }
        .sheet(item: $editing) { ClientEditor(client: $0) }
        .sheet(item: $survey) { SurveyEditor(clientID: id, survey: $0) }
        .alert("Eliminare cliente e tutte le indagini?", isPresented: $deleteClient) {
            Button("Annulla", role: .cancel) {}
            Button("Elimina", role: .destructive) {
                var next = store.archive; next.clients.removeAll { $0.id == id }
                if store.commit(next) { dismiss() }
            }
        } message: { Text("L’operazione non può essere annullata.") }
        .alert("Eliminare questa indagine?", isPresented: Binding(get: { deletingSurvey != nil }, set: { if !$0 { deletingSurvey = nil } })) {
            Button("Annulla", role: .cancel) { deletingSurvey = nil }
            Button("Elimina", role: .destructive) {
                if var c = client, let s = deletingSurvey { c.surveys.removeAll { $0.id == s.id }; _ = store.save(c) }
                deletingSurvey = nil
            }
        }
    }
}
struct Signal: View {
    let score: Int
    let settings: Settings
    var compact = false
    var color: Color { score < 0 ? .gray : score <= settings.redMax ? .red : score < settings.greenMin ? .orange : .green }
    var body: some View {
        HStack(spacing: 4) {
            Circle().fill(color).frame(width: 9, height: 9)
            Text(compact ? "\(score)" : settings.level(score)).font(.caption.weight(.semibold))
        }.accessibilityLabel("\(score < 0 ? "Da valutare" : String(score)), \(settings.level(score))")
    }
}
struct Wheel: View {
    let scores: [Int]
    let colors: [String]
    var body: some View {
        Canvas { context, size in
            let center = CGPoint(x: size.width/2, y: size.height/2)
            let radius = min(size.width, size.height)/2 - 22
            for i in 0..<6 {
                let start = Double(i)*60 - 90
                let end = start+60
                func sector(_ r: CGFloat) -> Path {
                    var p = Path(); p.move(to: center)
                    p.addArc(center: center, radius: r, startAngle: .degrees(start), endAngle: .degrees(end), clockwise: false)
                    p.closeSubpath(); return p
                }
                context.fill(sector(radius), with: .color(Color(hex: colors[i]).opacity(0.09)))
                if scores[i] > 0 { context.fill(sector(radius * CGFloat(scores[i])/10), with: .color(Color(hex: colors[i]).opacity(0.82))) }
                let angle = (start+30) * Double.pi / 180
                let pos = CGPoint(x: center.x + (radius+14)*cos(angle), y: center.y + (radius+14)*sin(angle))
                context.draw(Text("\(i+1)").font(.caption.bold()).foregroundColor(Color(hex: colors[i])), at: pos)
            }
            for n in 1...10 {
                let r = radius*CGFloat(n)/10
                context.stroke(Path(ellipseIn: CGRect(x: center.x-r, y: center.y-r, width: r*2, height: r*2)), with: .color(.secondary.opacity(0.32)), lineWidth: n == 10 ? 1.5 : 0.6)
                context.draw(Text("\(n)").font(.system(size: 8, weight: .semibold)).foregroundColor(.primary), at: CGPoint(x: center.x, y: center.y-r+5))
            }
            for i in 0..<6 {
                let a = (Double(i)*60-90) * Double.pi/180
                var line = Path(); line.move(to: center)
                line.addLine(to: CGPoint(x: center.x+radius*cos(a), y: center.y+radius*sin(a)))
                context.stroke(line, with: .color(.secondary.opacity(0.65)), lineWidth: 1)
            }
            context.draw(Text("0").font(.system(size: 8)), at: center)
        }.aspectRatio(1, contentMode: .fit)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Ruota: " + (0..<6).map { "\(areaNames[$0]), \(scores[$0] < 0 ? "da valutare" : String(scores[$0]))" }.joined(separator: "; "))
    }
}
struct SurveyEditor: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    let clientID: UUID
    @State var survey: Survey
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    DatePicker("Data e ora", selection: $survey.date)
                    TextField("Obiettivo dell’indagine", text: $survey.objective, axis: .vertical)
                }
                Section {
                    Wheel(scores: survey.scores, colors: survey.settings.colors)
                    Text("Ogni anello vale un punto. Usa − e + per colorare gli spicchi. Lo zero è una valutazione; “—” indica un’area ancora da valutare.").font(.caption).foregroundStyle(.secondary)
                }
                Section("Le sei aree") {
                    ForEach(0..<6) { i in
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Circle().fill(Color(hex: survey.settings.colors[i])).frame(width: 12, height: 12)
                                Text("\(i+1). \(areaNames[i])").font(.headline)
                            }
                            HStack {
                                Signal(score: survey.scores[i], settings: survey.settings)
                                Spacer()
                                Button { survey.scores[i] = max(0, survey.scores[i]-1) } label: { Image(systemName: "minus.circle.fill").font(.title2).frame(width: 44, height: 44) }.buttonStyle(.borderless).accessibilityLabel("Diminuisci \(areaNames[i])")
                                Text(survey.scores[i] < 0 ? "—" : "\(survey.scores[i])").font(.title2.bold().monospacedDigit()).frame(minWidth: 32)
                                Button { survey.scores[i] = min(10, survey.scores[i]+1) } label: { Image(systemName: "plus.circle.fill").font(.title2).frame(width: 44, height: 44) }.buttonStyle(.borderless).accessibilityLabel("Aumenta \(areaNames[i])")
                            }
                        }.padding(.vertical, 4)
                    }
                }
                Section("Semaforo") {
                    Text("Rosso 0–\(survey.settings.redMax) · Giallo \(survey.settings.redMax+1)–\(survey.settings.greenMin-1) · Verde \(survey.settings.greenMin)–10").font(.caption)
                    let low = survey.scores.indices.filter { survey.scores[$0] >= 0 && survey.scores[$0] < survey.settings.greenMin }
                    if !low.isEmpty { Text("Aree da approfondire: " + low.map { areaNames[$0] }.joined(separator: ", ")).font(.subheadline) }
                }
                Section("Note del coach") { TextEditor(text: $survey.notes).frame(minHeight: 160) }
                if !survey.complete { Section { Text("Assegna un voto a tutte e sei le aree per salvare.").font(.caption).foregroundStyle(.secondary) } }
            }.navigationTitle("Indagine")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Annulla") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) { Button("Salva") { if store.save(survey, for: clientID) { dismiss() } }.disabled(!survey.complete) }
                }
        }.interactiveDismissDisabled()
    }
}
struct BackupDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data
    init(data: Data) { self.data = data }
    init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}
struct SettingsView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    @State private var draft = Settings()
    @State private var export = false
    @State private var importing = false
    @State private var pending: Archive?
    @State private var document = BackupDocument(data: Data())
    var body: some View {
        NavigationStack {
            Form {
                Section("Colori degli spicchi") {
                    ForEach(0..<6) { i in
                        ColorPicker(areaNames[i], selection: Binding(get: { Color(hex: draft.colors[i]) }, set: { draft.colors[i] = $0.hex }), supportsOpacity: false)
                    }
                }
                Section("Soglie del semaforo") {
                    Stepper("Rosso fino a \(draft.redMax)", value: $draft.redMax, in: 0...max(0, draft.greenMin-2))
                    Stepper("Verde da \(draft.greenMin)", value: $draft.greenMin, in: min(10, draft.redMax+2)...10)
                    Text("Giallo da \(draft.redMax+1) a \(draft.greenMin-1). Colori e soglie si applicano alle nuove indagini; quelle salvate mantengono le impostazioni originali.").font(.caption)
                }
                Section("Archivio e backup") {
                    Text("I dati sono salvati su questo iPhone quando premi Salva. Nessun account o server dell’app. Esporta una copia prima di disinstallare o cambiare dispositivo.").font(.caption)
                    Button("Esporta backup JSON") {
                        do { document = BackupDocument(data: try JSONEncoder().encode(store.archive)); export = true }
                        catch { store.error = error.localizedDescription }
                    }.disabled(store.loadFailed)
                    Button("Ripristina da backup") { importing = true }
                    Text("Il backup contiene nominativi e note in chiaro. Scegli tu dove conservarlo nell’app File.").font(.caption).foregroundStyle(.secondary)
                }
            }.navigationTitle("Impostazioni")
                .onAppear { draft = store.archive.settings }
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Chiudi") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) { Button("Salva") { var next = store.archive; next.settings = draft; if store.commit(next) { dismiss() } }.disabled(store.loadFailed) }
                }
                .fileExporter(isPresented: $export, document: document, contentType: .json, defaultFilename: "RuotaCoach-backup") { result in
                    if case .failure(let e) = result { store.error = e.localizedDescription }
                }
                .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                    do {
                        let url = try result.get()
                        let access = url.startAccessingSecurityScopedResource()
                        defer { if access { url.stopAccessingSecurityScopedResource() } }
                        let archive = try JSONDecoder().decode(Archive.self, from: Data(contentsOf: url))
                        try archive.validate(); pending = archive
                    } catch { store.error = error.localizedDescription }
                }
                .alert("Sostituire l’archivio attuale?", isPresented: Binding(get: { pending != nil }, set: { if !$0 { pending = nil } })) {
                    Button("Annulla", role: .cancel) { pending = nil }
                    Button("Ripristina", role: .destructive) {
                        if let next = pending, store.commit(next, recovery: true) { draft = next.settings }
                        pending = nil
                    }
                } message: { Text("Il backup contiene \(pending?.clients.count ?? 0) clienti. Esporta prima i dati attuali se vuoi conservarne una copia accessibile.") }
        }
    }
}
